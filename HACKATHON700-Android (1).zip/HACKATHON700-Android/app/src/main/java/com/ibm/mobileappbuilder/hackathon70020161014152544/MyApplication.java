

package com.ibm.mobileappbuilder.hackathon70020161014152544;

import android.app.Application;
import ibmmobileappbuilder.injectors.ApplicationInjector;
import android.support.multidex.MultiDexApplication;
import android.app.Activity;
import android.os.Bundle;
import ibmmobileappbuilder.util.SecurePreferences;
import com.ibm.mobileappbuilder.hackathon70020161014152544.ui.LoginActivity;
import ibmmobileappbuilder.util.LoginUtils;
import ibmmobileappbuilder.cloudant.factory.CloudantDatabaseSyncerFactory;
import java.net.URI;


/**
 * You can use this as a global place to keep application-level resources
 * such as singletons, services, etc.
 */
public class MyApplication extends MultiDexApplication implements Application.ActivityLifecycleCallbacks {
    private SecurePreferences mSharedPreferences;

    @Override
    public void onCreate() {
        super.onCreate();
        ApplicationInjector.setApplicationContext(this);
        mSharedPreferences = new SecurePreferences(this);
        registerActivityLifecycleCallbacks(this);

        mSharedPreferences.edit().putLong(LoginUtils.EXPIRATION_TIME, LoginUtils.SESSION_EXPIRED).apply();
        //Syncing cloudant ds
        CloudantDatabaseSyncerFactory.instanceFor(
            "hack1",
            URI.create("https://b083665d-14d8-4259-a780-76c287d75410-bluemix:e923d439d2f0596eb5ad68668167723726029834caee2b9a48a4fd806cbdd6ae@b083665d-14d8-4259-a780-76c287d75410-bluemix.cloudant.com/hack1/")
        ).sync(null);
          CloudantDatabaseSyncerFactory.instanceFor(
            "perfil",
            URI.create("https://b083665d-14d8-4259-a780-76c287d75410-bluemix:e923d439d2f0596eb5ad68668167723726029834caee2b9a48a4fd806cbdd6ae@b083665d-14d8-4259-a780-76c287d75410-bluemix.cloudant.com/perfil/")
        ).sync(null);
      }

    public SecurePreferences getSecureSharedPreferences() {
        return mSharedPreferences;
    }

    @Override
    public void onActivityCreated(Activity activity, Bundle bundle) {
    }

    @Override
    public void onActivityStarted(Activity activity) {
        boolean splashShown = false;
        if(!splashShown && !(activity instanceof LoginActivity) ){
            LoginUtils.checkLoggedStatus(mSharedPreferences, LoginActivity.class, activity);
        }
    }

    @Override
    public void onActivityResumed(Activity activity) {
    }

    @Override
    public void onActivityPaused(Activity activity) {
    }

    @Override
    public void onActivityStopped(Activity activity) {
        if(!(activity instanceof LoginActivity) ) {
            LoginUtils.storeLastActiveStatus(mSharedPreferences);
        }
    }

    @Override
    public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {

    }

    @Override
    public void onActivityDestroyed(Activity activity) {

    }


}

