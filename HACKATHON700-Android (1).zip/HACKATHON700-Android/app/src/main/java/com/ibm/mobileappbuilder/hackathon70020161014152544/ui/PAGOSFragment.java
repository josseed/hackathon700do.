
package com.ibm.mobileappbuilder.hackathon70020161014152544.ui;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import com.ibm.mobileappbuilder.hackathon70020161014152544.R;
import ibmmobileappbuilder.ds.Datasource;
import android.widget.ImageView;
import android.widget.TextView;
import ibmmobileappbuilder.ds.restds.AppNowDatasource;
import ibmmobileappbuilder.util.image.ImageLoader;
import ibmmobileappbuilder.util.image.PicassoImageLoader;
import ibmmobileappbuilder.util.StringUtils;
import java.net.URL;
import static ibmmobileappbuilder.util.image.ImageLoaderRequest.Builder.imageLoaderRequest;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.mobileappbuilder.hackathon70020161014152544.ds.PAGOSDSItem;
import com.ibm.mobileappbuilder.hackathon70020161014152544.ds.PAGOSDS;

public class PAGOSFragment extends ibmmobileappbuilder.ui.DetailFragment<PAGOSDSItem>  {

    private Datasource<PAGOSDSItem> datasource;
    private SearchOptions searchOptions;

    public static PAGOSFragment newInstance(Bundle args){
        PAGOSFragment card = new PAGOSFragment();
        card.setArguments(args);

        return card;
    }

    public PAGOSFragment(){
        super();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
            searchOptions = SearchOptions.Builder.searchOptions().build();
    }

    @Override
    public Datasource getDatasource() {
      if (datasource != null) {
          return datasource;
      }
          datasource = PAGOSDS.getInstance(searchOptions);
          return datasource;
    }

    // Bindings

    @Override
    protected int getLayout() {
        return R.layout.pagos_custom;
    }

    @Override
    @SuppressLint("WrongViewCast")
    public void bindView(final PAGOSDSItem item, View view) {
        if (item.pagosrecibidos != null){
            
            TextView view0 = (TextView) view.findViewById(R.id.view0);
            view0.setText("Pagos Recibidos: " + item.pagosrecibidos + " ");
            
        }
        if (item.clientesInscritos != null){
            
            TextView view1 = (TextView) view.findViewById(R.id.view1);
            view1.setText("Clientes Inscritos: " + item.clientesInscritos);
            
        }
        if (item.serviciosInscritos != null){
            
            TextView view2 = (TextView) view.findViewById(R.id.view2);
            view2.setText("Servicios Inscritos: " + item.serviciosInscritos);
            
        }
        
        TextView view3 = (TextView) view.findViewById(R.id.view3);
        view3.setText("MercadoPago, Casas Comerciales, Redbanc y Transbank.");
        
        
        TextView view4 = (TextView) view.findViewById(R.id.view4);
        view4.setText("Entre mas usuarios invites, recomiendes y registres mas podras ganar. Comienza con nosotros ahora.");
        
        
        ImageView view5 = (ImageView) view.findViewById(R.id.view5);
        URL view5Media = ((AppNowDatasource) getDatasource()).getImageUrl(item.logoo);
        if(view5Media != null){
          ImageLoader imageLoader = new PicassoImageLoader(view5.getContext());
          imageLoader.load(imageLoaderRequest()
                                   .withPath(view5Media.toExternalForm())
                                   .withTargetView(view5)
                                   .fit()
                                   .build()
                    );
        	
        } else {
          view5.setImageDrawable(null);
        }
    }

    @Override
    protected void onShow(PAGOSDSItem item) {
        // set the title for this fragment
        getActivity().setTitle("PAGOS");
    }

}

