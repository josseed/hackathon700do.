
package com.ibm.mobileappbuilder.hackathon70020161014152544.ds;
import android.graphics.Bitmap;
import android.net.Uri;

import ibmmobileappbuilder.mvp.model.IdentifiableBean;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class RegistroDSItem implements Parcelable, IdentifiableBean {

    @SerializedName("contactar") public String contactar;
    @SerializedName("usuario") public String usuario;
    @SerializedName("nombre") public String nombre;
    @SerializedName("empresa") public String empresa;
    @SerializedName("logo") public String logo;
    @SerializedName("id") public String id;
    @SerializedName("logoUri") public transient Uri logoUri;

    @Override
    public String getIdentifiableId() {
      return id;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(contactar);
        dest.writeString(usuario);
        dest.writeString(nombre);
        dest.writeString(empresa);
        dest.writeString(logo);
        dest.writeString(id);
    }

    public static final Creator<RegistroDSItem> CREATOR = new Creator<RegistroDSItem>() {
        @Override
        public RegistroDSItem createFromParcel(Parcel in) {
            RegistroDSItem item = new RegistroDSItem();

            item.contactar = in.readString();
            item.usuario = in.readString();
            item.nombre = in.readString();
            item.empresa = in.readString();
            item.logo = in.readString();
            item.id = in.readString();
            return item;
        }

        @Override
        public RegistroDSItem[] newArray(int size) {
            return new RegistroDSItem[size];
        }
    };

}


