
package com.ibm.mobileappbuilder.hackathon70020161014152544.ds;
import java.util.List;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Query;
import retrofit.http.POST;
import retrofit.http.Body;
import retrofit.http.DELETE;
import retrofit.http.Path;
import retrofit.http.PUT;
import retrofit.mime.TypedByteArray;
import retrofit.http.Part;
import retrofit.http.Multipart;

public interface Perfil1DSServiceRest{

	@GET("/app/58012744dbd6f5030033a668/r/perfil1DS")
	void queryPerfil1DSItem(
		@Query("skip") String skip,
		@Query("limit") String limit,
		@Query("conditions") String conditions,
		@Query("sort") String sort,
		@Query("select") String select,
		@Query("populate") String populate,
		Callback<List<Perfil1DSItem>> cb);

	@GET("/app/58012744dbd6f5030033a668/r/perfil1DS/{id}")
	void getPerfil1DSItemById(@Path("id") String id, Callback<Perfil1DSItem> cb);

	@DELETE("/app/58012744dbd6f5030033a668/r/perfil1DS/{id}")
  void deletePerfil1DSItemById(@Path("id") String id, Callback<Perfil1DSItem> cb);

  @POST("/app/58012744dbd6f5030033a668/r/perfil1DS/deleteByIds")
  void deleteByIds(@Body List<String> ids, Callback<List<Perfil1DSItem>> cb);

  @POST("/app/58012744dbd6f5030033a668/r/perfil1DS")
  void createPerfil1DSItem(@Body Perfil1DSItem item, Callback<Perfil1DSItem> cb);

  @PUT("/app/58012744dbd6f5030033a668/r/perfil1DS/{id}")
  void updatePerfil1DSItem(@Path("id") String id, @Body Perfil1DSItem item, Callback<Perfil1DSItem> cb);

  @GET("/app/58012744dbd6f5030033a668/r/perfil1DS")
  void distinct(
        @Query("distinct") String colName,
        @Query("conditions") String conditions,
        Callback<List<String>> cb);
    
    @Multipart
    @POST("/app/58012744dbd6f5030033a668/r/perfil1DS")
    void createPerfil1DSItem(
        @Part("data") Perfil1DSItem item,
        @Part("logo") TypedByteArray logo,
        Callback<Perfil1DSItem> cb);
    
    @Multipart
    @PUT("/app/58012744dbd6f5030033a668/r/perfil1DS/{id}")
    void updatePerfil1DSItem(
        @Path("id") String id,
        @Part("data") Perfil1DSItem item,
        @Part("logo") TypedByteArray logo,
        Callback<Perfil1DSItem> cb);
}

