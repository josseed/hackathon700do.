
package com.ibm.mobileappbuilder.hackathon70020161014152544.ds;
import android.graphics.Bitmap;
import android.graphics.Bitmap;
import android.net.Uri;
import android.net.Uri;

import ibmmobileappbuilder.mvp.model.IdentifiableBean;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class PAGOSDSItem implements Parcelable, IdentifiableBean {

    @SerializedName("pagosrecibidos") public String pagosrecibidos;
    @SerializedName("clientesInscritos") public String clientesInscritos;
    @SerializedName("mediosdepago") public String mediosdepago;
    @SerializedName("serviciosInscritos") public String serviciosInscritos;
    @SerializedName("tipodeCuenta") public String tipodeCuenta;
    @SerializedName("numerodeCuenta") public String numerodeCuenta;
    @SerializedName("banco") public String banco;
    @SerializedName("logoo") public String logoo;
    @SerializedName("id") public String id;
    @SerializedName("mediosdepagoUri") public transient Uri mediosdepagoUri;
    @SerializedName("logooUri") public transient Uri logooUri;

    @Override
    public String getIdentifiableId() {
      return id;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(pagosrecibidos);
        dest.writeString(clientesInscritos);
        dest.writeString(mediosdepago);
        dest.writeString(serviciosInscritos);
        dest.writeString(tipodeCuenta);
        dest.writeString(numerodeCuenta);
        dest.writeString(banco);
        dest.writeString(logoo);
        dest.writeString(id);
    }

    public static final Creator<PAGOSDSItem> CREATOR = new Creator<PAGOSDSItem>() {
        @Override
        public PAGOSDSItem createFromParcel(Parcel in) {
            PAGOSDSItem item = new PAGOSDSItem();

            item.pagosrecibidos = in.readString();
            item.clientesInscritos = in.readString();
            item.mediosdepago = in.readString();
            item.serviciosInscritos = in.readString();
            item.tipodeCuenta = in.readString();
            item.numerodeCuenta = in.readString();
            item.banco = in.readString();
            item.logoo = in.readString();
            item.id = in.readString();
            return item;
        }

        @Override
        public PAGOSDSItem[] newArray(int size) {
            return new PAGOSDSItem[size];
        }
    };

}


