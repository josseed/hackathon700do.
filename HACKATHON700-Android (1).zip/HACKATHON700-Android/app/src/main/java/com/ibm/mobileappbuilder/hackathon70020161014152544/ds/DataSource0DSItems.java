

package com.ibm.mobileappbuilder.hackathon70020161014152544.ds;
import java.net.URL;
import ibmmobileappbuilder.util.StringUtils;
import java.net.URL;
import ibmmobileappbuilder.util.StringUtils;
import com.ibm.mobileappbuilder.hackathon70020161014152544.R;
import java.util.ArrayList;
import java.util.List;
import ibmmobileappbuilder.util.StringUtils;

// DataSource0DSSchemaItem static data
public class DataSource0DSItems{

    public static List<DataSource0DSSchemaItem> ITEMS = new ArrayList<DataSource0DSSchemaItem>();
    public static void addItem(DataSource0DSSchemaItem item) {
        ITEMS.add(item);
    }
}


