
package com.ibm.mobileappbuilder.hackathon70020161014152544.ds;

import ibmmobileappbuilder.mvp.model.MutableIdentifiableBean;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class HackathonDSSchemaItem implements Parcelable, MutableIdentifiableBean {

    private transient String cloudantIdentifiableId;

    @SerializedName("empresa") public String empresa;
    @SerializedName("telefono") public String telefono;
    @SerializedName("mail") public String mail;
    @SerializedName("nombre") public String nombre;
    @SerializedName("apellido") public String apellido;
    @SerializedName("Descripcion") public String descripcion;
    @SerializedName("rut") public String rut;
    @SerializedName("direccion") public String direccion;
    @SerializedName("price") public String price;
    @SerializedName("ganancia") public String ganancia;
    @SerializedName("Slogan") public String slogan;
    @SerializedName("btn") public String btn;
    @SerializedName("btn2") public String btn2;
    @SerializedName("mpago") public String mpago;

    @Override
    public void setIdentifiableId(String id) {
        this.cloudantIdentifiableId = id;
    }

    @Override
    public String getIdentifiableId() {
        return cloudantIdentifiableId;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(cloudantIdentifiableId);
        dest.writeString(empresa);
        dest.writeString(telefono);
        dest.writeString(mail);
        dest.writeString(nombre);
        dest.writeString(apellido);
        dest.writeString(descripcion);
        dest.writeString(rut);
        dest.writeString(direccion);
        dest.writeString(price);
        dest.writeString(ganancia);
        dest.writeString(slogan);
        dest.writeString(btn);
        dest.writeString(btn2);
        dest.writeString(mpago);
    }

    public static final Creator<HackathonDSSchemaItem> CREATOR = new Creator<HackathonDSSchemaItem>() {
        @Override
        public HackathonDSSchemaItem createFromParcel(Parcel in) {
            HackathonDSSchemaItem item = new HackathonDSSchemaItem();
            item.cloudantIdentifiableId = in.readString();

            item.empresa = in.readString();
            item.telefono = in.readString();
            item.mail = in.readString();
            item.nombre = in.readString();
            item.apellido = in.readString();
            item.descripcion = in.readString();
            item.rut = in.readString();
            item.direccion = in.readString();
            item.price = in.readString();
            item.ganancia = in.readString();
            item.slogan = in.readString();
            item.btn = in.readString();
            item.btn2 = in.readString();
            item.mpago = in.readString();
            return item;
        }

        @Override
        public HackathonDSSchemaItem[] newArray(int size) {
            return new HackathonDSSchemaItem[size];
        }
    };
}


