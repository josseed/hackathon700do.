
package com.ibm.mobileappbuilder.hackathon70020161014152544.ds;
import java.util.List;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Query;
import retrofit.http.POST;
import retrofit.http.Body;
import retrofit.http.DELETE;
import retrofit.http.Path;
import retrofit.http.PUT;
import retrofit.mime.TypedByteArray;
import retrofit.http.Part;
import retrofit.http.Multipart;

public interface PAGOSDSServiceRest{

	@GET("/app/58012744dbd6f5030033a668/r/pAGOSDS")
	void queryPAGOSDSItem(
		@Query("skip") String skip,
		@Query("limit") String limit,
		@Query("conditions") String conditions,
		@Query("sort") String sort,
		@Query("select") String select,
		@Query("populate") String populate,
		Callback<List<PAGOSDSItem>> cb);

	@GET("/app/58012744dbd6f5030033a668/r/pAGOSDS/{id}")
	void getPAGOSDSItemById(@Path("id") String id, Callback<PAGOSDSItem> cb);

	@DELETE("/app/58012744dbd6f5030033a668/r/pAGOSDS/{id}")
  void deletePAGOSDSItemById(@Path("id") String id, Callback<PAGOSDSItem> cb);

  @POST("/app/58012744dbd6f5030033a668/r/pAGOSDS/deleteByIds")
  void deleteByIds(@Body List<String> ids, Callback<List<PAGOSDSItem>> cb);

  @POST("/app/58012744dbd6f5030033a668/r/pAGOSDS")
  void createPAGOSDSItem(@Body PAGOSDSItem item, Callback<PAGOSDSItem> cb);

  @PUT("/app/58012744dbd6f5030033a668/r/pAGOSDS/{id}")
  void updatePAGOSDSItem(@Path("id") String id, @Body PAGOSDSItem item, Callback<PAGOSDSItem> cb);

  @GET("/app/58012744dbd6f5030033a668/r/pAGOSDS")
  void distinct(
        @Query("distinct") String colName,
        @Query("conditions") String conditions,
        Callback<List<String>> cb);
    
    @Multipart
    @POST("/app/58012744dbd6f5030033a668/r/pAGOSDS")
    void createPAGOSDSItem(
        @Part("data") PAGOSDSItem item,
        @Part("mediosdepago") TypedByteArray mediosdepago,
    @Part("logoo") TypedByteArray logoo,
        Callback<PAGOSDSItem> cb);
    
    @Multipart
    @PUT("/app/58012744dbd6f5030033a668/r/pAGOSDS/{id}")
    void updatePAGOSDSItem(
        @Path("id") String id,
        @Part("data") PAGOSDSItem item,
        @Part("mediosdepago") TypedByteArray mediosdepago,
    @Part("logoo") TypedByteArray logoo,
        Callback<PAGOSDSItem> cb);
}

