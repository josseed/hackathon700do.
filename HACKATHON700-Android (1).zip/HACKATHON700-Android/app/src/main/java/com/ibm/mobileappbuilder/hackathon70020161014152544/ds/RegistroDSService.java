
package com.ibm.mobileappbuilder.hackathon70020161014152544.ds;
import java.net.URL;
import com.ibm.mobileappbuilder.hackathon70020161014152544.R;
import ibmmobileappbuilder.ds.RestService;
import ibmmobileappbuilder.util.StringUtils;

/**
 * "RegistroDSService" REST Service implementation
 */
public class RegistroDSService extends RestService<RegistroDSServiceRest>{

    public static RegistroDSService getInstance(){
          return new RegistroDSService();
    }

    private RegistroDSService() {
        super(RegistroDSServiceRest.class);

    }

    @Override
    public String getServerUrl() {
        return "https://ibm-pods.buildup.io";
    }

    @Override
    protected String getApiKey() {
        return "kE00bekU";
    }

    @Override
    public URL getImageUrl(String path){
        return StringUtils.parseUrl("https://ibm-pods.buildup.io/app/58012744dbd6f5030033a668",
                path,
                "apikey=kE00bekU");
    }

}

