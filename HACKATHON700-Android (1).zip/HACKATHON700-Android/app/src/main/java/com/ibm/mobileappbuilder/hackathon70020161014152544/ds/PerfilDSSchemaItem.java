
package com.ibm.mobileappbuilder.hackathon70020161014152544.ds;

import ibmmobileappbuilder.mvp.model.MutableIdentifiableBean;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class PerfilDSSchemaItem implements Parcelable, MutableIdentifiableBean {

    private transient String cloudantIdentifiableId;

    @SerializedName("pefil") public String pefil;
    @SerializedName("pagos") public String pagos;

    @Override
    public void setIdentifiableId(String id) {
        this.cloudantIdentifiableId = id;
    }

    @Override
    public String getIdentifiableId() {
        return cloudantIdentifiableId;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(cloudantIdentifiableId);
        dest.writeString(pefil);
        dest.writeString(pagos);
    }

    public static final Creator<PerfilDSSchemaItem> CREATOR = new Creator<PerfilDSSchemaItem>() {
        @Override
        public PerfilDSSchemaItem createFromParcel(Parcel in) {
            PerfilDSSchemaItem item = new PerfilDSSchemaItem();
            item.cloudantIdentifiableId = in.readString();

            item.pefil = in.readString();
            item.pagos = in.readString();
            return item;
        }

        @Override
        public PerfilDSSchemaItem[] newArray(int size) {
            return new PerfilDSSchemaItem[size];
        }
    };
}


