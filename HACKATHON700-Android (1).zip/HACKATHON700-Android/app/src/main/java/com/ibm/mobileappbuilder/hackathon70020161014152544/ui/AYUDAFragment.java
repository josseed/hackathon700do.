
package com.ibm.mobileappbuilder.hackathon70020161014152544.ui;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import com.ibm.mobileappbuilder.hackathon70020161014152544.R;
import ibmmobileappbuilder.ds.Datasource;
import android.widget.ImageView;
import android.widget.TextView;
import ibmmobileappbuilder.ds.restds.AppNowDatasource;
import ibmmobileappbuilder.util.image.ImageLoader;
import ibmmobileappbuilder.util.image.PicassoImageLoader;
import ibmmobileappbuilder.util.StringUtils;
import java.net.URL;
import static ibmmobileappbuilder.util.image.ImageLoaderRequest.Builder.imageLoaderRequest;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.mobileappbuilder.hackathon70020161014152544.ds.RegistroDSItem;
import com.ibm.mobileappbuilder.hackathon70020161014152544.ds.RegistroDS;

public class AYUDAFragment extends ibmmobileappbuilder.ui.DetailFragment<RegistroDSItem>  {

    private Datasource<RegistroDSItem> datasource;
    private SearchOptions searchOptions;

    public static AYUDAFragment newInstance(Bundle args){
        AYUDAFragment card = new AYUDAFragment();
        card.setArguments(args);

        return card;
    }

    public AYUDAFragment(){
        super();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
            searchOptions = SearchOptions.Builder.searchOptions().build();
    }

    @Override
    public Datasource getDatasource() {
      if (datasource != null) {
          return datasource;
      }
          datasource = RegistroDS.getInstance(searchOptions);
          return datasource;
    }

    // Bindings

    @Override
    protected int getLayout() {
        return R.layout.ayuda_custom;
    }

    @Override
    @SuppressLint("WrongViewCast")
    public void bindView(final RegistroDSItem item, View view) {
        
        TextView view0 = (TextView) view.findViewById(R.id.view0);
        view0.setText("..............................................");
        
        
        TextView view1 = (TextView) view.findViewById(R.id.view1);
        view1.setText("...............................................");
        
        
        TextView view2 = (TextView) view.findViewById(R.id.view2);
        view2.setText("................................................");
        
        
        TextView view3 = (TextView) view.findViewById(R.id.view3);
        view3.setText("................................................");
        
        
        ImageView view4 = (ImageView) view.findViewById(R.id.view4);
        URL view4Media = ((AppNowDatasource) getDatasource()).getImageUrl(item.logo);
        if(view4Media != null){
          ImageLoader imageLoader = new PicassoImageLoader(view4.getContext());
          imageLoader.load(imageLoaderRequest()
                                   .withPath(view4Media.toExternalForm())
                                   .withTargetView(view4)
                                   .fit()
                                   .build()
                    );
        	
        } else {
          view4.setImageDrawable(null);
        }
    }

    @Override
    protected void onShow(RegistroDSItem item) {
        // set the title for this fragment
        getActivity().setTitle("AYUDA");
    }

}

