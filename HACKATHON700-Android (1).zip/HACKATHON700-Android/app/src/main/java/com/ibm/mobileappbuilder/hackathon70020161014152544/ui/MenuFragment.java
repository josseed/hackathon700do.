

package com.ibm.mobileappbuilder.hackathon70020161014152544.ui;

import android.os.Bundle;

import com.ibm.mobileappbuilder.hackathon70020161014152544.R;

import java.util.ArrayList;
import java.util.List;

import ibmmobileappbuilder.MenuItem;

import ibmmobileappbuilder.actions.StartActivityAction;
import ibmmobileappbuilder.util.Constants;

/**
 * MenuFragment menu fragment.
 */
public class MenuFragment extends ibmmobileappbuilder.ui.MenuFragment {

    /**
     * Default constructor
     */
    public MenuFragment(){
        super();
    }

    // Factory method
    public static MenuFragment newInstance(Bundle args) {
        MenuFragment fragment = new MenuFragment();

        fragment.setArguments(args);
        return fragment;
    }

    @Override
      public void onCreate(Bundle savedInstanceState) {
          super.onCreate(savedInstanceState);
                }

    // Menu Fragment interface
    @Override
    public List<MenuItem> getMenuItems() {
        ArrayList<MenuItem> items = new ArrayList<MenuItem>();
        items.add(new MenuItem()
            .setLabel("EMPRESAS")
            .setIcon(R.drawable.png_headserviciosdolphins611)
            .setAction(new StartActivityAction(EMPRESASMenuItem1Activity.class, Constants.DETAIL))
        );
        items.add(new MenuItem()
            .setLabel("PERFIL")
            .setIcon(R.drawable.png_user33638960720620)
            .setAction(new StartActivityAction(PerfilActivity.class, Constants.DETAIL))
        );
        items.add(new MenuItem()
            .setLabel("CONTACTAR")
            .setIcon(R.drawable.png_logoinscripcion734)
            .setAction(new StartActivityAction(INSCRIBIRActivity.class, Constants.DETAIL))
        );
        items.add(new MenuItem()
            .setLabel("AYUDA")
            .setIcon(R.drawable.png_help124)
            .setAction(new StartActivityAction(AYUDAActivity.class, Constants.DETAIL))
        );
        items.add(new MenuItem()
            .setLabel("HISTORIAL")
            .setIcon(R.drawable.png_businesscolormoneytimeiconiconscom53444989)
            .setAction(new StartActivityAction(PAGOSActivity.class, Constants.DETAIL))
        );
        return items;
    }

    @Override
    public int getLayout() {
        return R.layout.fragment_grid;
    }

    @Override
    public int getItemLayout() {
        return R.layout.menu_item;
    }
}

