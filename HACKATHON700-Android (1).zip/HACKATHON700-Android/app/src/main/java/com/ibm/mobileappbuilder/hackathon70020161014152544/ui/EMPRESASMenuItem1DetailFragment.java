
package com.ibm.mobileappbuilder.hackathon70020161014152544.ui;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import com.ibm.mobileappbuilder.hackathon70020161014152544.R;
import ibmmobileappbuilder.util.image.ImageLoader;
import ibmmobileappbuilder.util.image.PicassoImageLoader;
import ibmmobileappbuilder.util.StringUtils;
import java.net.URL;
import static ibmmobileappbuilder.util.image.ImageLoaderRequest.Builder.imageLoaderRequest;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.mobileappbuilder.hackathon70020161014152544.ds.HackathonDSSchemaItem;
import ibmmobileappbuilder.ds.CloudantDatasource;
import ibmmobileappbuilder.cloudant.factory.CloudantDatastoresFactory;
import java.net.URI;

public class EMPRESASMenuItem1DetailFragment extends ibmmobileappbuilder.ui.DetailFragment<HackathonDSSchemaItem>  {

    private Datasource<HackathonDSSchemaItem> datasource;
    public static EMPRESASMenuItem1DetailFragment newInstance(Bundle args){
        EMPRESASMenuItem1DetailFragment fr = new EMPRESASMenuItem1DetailFragment();
        fr.setArguments(args);

        return fr;
    }

    public EMPRESASMenuItem1DetailFragment(){
        super();
    }

    @Override
    public Datasource<HackathonDSSchemaItem> getDatasource() {
      if (datasource != null) {
        return datasource;
      }
       datasource = CloudantDatasource.cloudantDatasource(
              CloudantDatastoresFactory.create("hack1"),
              URI.create("https://b083665d-14d8-4259-a780-76c287d75410-bluemix:e923d439d2f0596eb5ad68668167723726029834caee2b9a48a4fd806cbdd6ae@b083665d-14d8-4259-a780-76c287d75410-bluemix.cloudant.com/hack1/"),
              HackathonDSSchemaItem.class,
              new SearchOptions(),
              null
      );
        return datasource;
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);

    }

    // Bindings

    @Override
    protected int getLayout() {
        return R.layout.empresasmenuitem1detail_detail;
    }

    @Override
    @SuppressLint("WrongViewCast")
    public void bindView(final HackathonDSSchemaItem item, View view) {
        
        ImageView view0 = (ImageView) view.findViewById(R.id.view0);
        URL view0Media = StringUtils.parseUrl(item.slogan);
        if(view0Media != null){
          ImageLoader imageLoader = new PicassoImageLoader(view0.getContext());
          imageLoader.load(imageLoaderRequest()
                                   .withPath(view0Media.toExternalForm())
                                   .withTargetView(view0)
                                   .fit()
                                   .build()
                    );
        	
        } else {
          view0.setImageDrawable(null);
        }
        if (item.empresa != null){
            
            TextView view1 = (TextView) view.findViewById(R.id.view1);
            view1.setText(item.empresa);
            
        }
        if (item.descripcion != null){
            
            TextView view2 = (TextView) view.findViewById(R.id.view2);
            view2.setText(item.descripcion);
            
        }
        if (item.price != null){
            
            TextView view3 = (TextView) view.findViewById(R.id.view3);
            view3.setText("Precio: " + item.price);
            
        }
        if (item.ganancia != null){
            
            TextView view4 = (TextView) view.findViewById(R.id.view4);
            view4.setText(item.ganancia);
            
        }
        if (item.direccion != null){
            
            TextView view5 = (TextView) view.findViewById(R.id.view5);
            view5.setText(item.direccion);
            
        }
        
        ImageView view6 = (ImageView) view.findViewById(R.id.view6);
        URL view6Media = StringUtils.parseUrl(item.btn);
        if(view6Media != null){
          ImageLoader imageLoader = new PicassoImageLoader(view6.getContext());
          imageLoader.load(imageLoaderRequest()
                                   .withPath(view6Media.toExternalForm())
                                   .withTargetView(view6)
                                   .fit()
                                   .build()
                    );
        	
        } else {
          view6.setImageDrawable(null);
        }
        
        ImageView view7 = (ImageView) view.findViewById(R.id.view7);
        URL view7Media = StringUtils.parseUrl(item.mpago);
        if(view7Media != null){
          ImageLoader imageLoader = new PicassoImageLoader(view7.getContext());
          imageLoader.load(imageLoaderRequest()
                                   .withPath(view7Media.toExternalForm())
                                   .withTargetView(view7)
                                   .fit()
                                   .build()
                    );
        	
        } else {
          view7.setImageDrawable(null);
        }
    }

    @Override
    protected void onShow(HackathonDSSchemaItem item) {
        // set the title for this fragment
        getActivity().setTitle("Empresas");
    }
}

