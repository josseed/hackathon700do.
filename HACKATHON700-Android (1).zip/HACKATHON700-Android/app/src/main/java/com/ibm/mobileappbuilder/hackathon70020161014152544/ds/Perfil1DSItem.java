
package com.ibm.mobileappbuilder.hackathon70020161014152544.ds;
import android.graphics.Bitmap;
import android.net.Uri;

import ibmmobileappbuilder.mvp.model.IdentifiableBean;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class Perfil1DSItem implements Parcelable, IdentifiableBean {

    @SerializedName("usuario") public String usuario;
    @SerializedName("empresa") public String empresa;
    @SerializedName("correo") public String correo;
    @SerializedName("pais") public String pais;
    @SerializedName("logo") public String logo;
    @SerializedName("banco") public String banco;
    @SerializedName("numerodeCuenta") public String numerodeCuenta;
    @SerializedName("tipodeCuenta") public String tipodeCuenta;
    @SerializedName("id") public String id;
    @SerializedName("logoUri") public transient Uri logoUri;

    @Override
    public String getIdentifiableId() {
      return id;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(usuario);
        dest.writeString(empresa);
        dest.writeString(correo);
        dest.writeString(pais);
        dest.writeString(logo);
        dest.writeString(banco);
        dest.writeString(numerodeCuenta);
        dest.writeString(tipodeCuenta);
        dest.writeString(id);
    }

    public static final Creator<Perfil1DSItem> CREATOR = new Creator<Perfil1DSItem>() {
        @Override
        public Perfil1DSItem createFromParcel(Parcel in) {
            Perfil1DSItem item = new Perfil1DSItem();

            item.usuario = in.readString();
            item.empresa = in.readString();
            item.correo = in.readString();
            item.pais = in.readString();
            item.logo = in.readString();
            item.banco = in.readString();
            item.numerodeCuenta = in.readString();
            item.tipodeCuenta = in.readString();
            item.id = in.readString();
            return item;
        }

        @Override
        public Perfil1DSItem[] newArray(int size) {
            return new Perfil1DSItem[size];
        }
    };

}


