
package com.ibm.mobileappbuilder.hackathon70020161014152544.ui;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import com.ibm.mobileappbuilder.hackathon70020161014152544.R;
import ibmmobileappbuilder.ds.Datasource;
import android.widget.TextView;
import ibmmobileappbuilder.actions.ActivityIntentLauncher;
import ibmmobileappbuilder.actions.MailAction;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.mobileappbuilder.hackathon70020161014152544.ds.RegistroDSItem;
import com.ibm.mobileappbuilder.hackathon70020161014152544.ds.RegistroDS;

public class INSCRIBIRFragment extends ibmmobileappbuilder.ui.DetailFragment<RegistroDSItem>  {

    private Datasource<RegistroDSItem> datasource;
    private SearchOptions searchOptions;

    public static INSCRIBIRFragment newInstance(Bundle args){
        INSCRIBIRFragment card = new INSCRIBIRFragment();
        card.setArguments(args);

        return card;
    }

    public INSCRIBIRFragment(){
        super();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
            searchOptions = SearchOptions.Builder.searchOptions().build();
    }

    @Override
    public Datasource getDatasource() {
      if (datasource != null) {
          return datasource;
      }
          datasource = RegistroDS.getInstance(searchOptions);
          return datasource;
    }

    // Bindings

    @Override
    protected int getLayout() {
        return R.layout.inscribir_custom;
    }

    @Override
    @SuppressLint("WrongViewCast")
    public void bindView(final RegistroDSItem item, View view) {
        
        TextView view0 = (TextView) view.findViewById(R.id.view0);
        view0.setText("Deseas ser parte de MILLONARIOS, solo contactanos y comienza ganar clientes para tu empresa y compensa a los usuarios.");
        
        
        TextView view2 = (TextView) view.findViewById(R.id.view2);
        view2.setText("contacto@millonarios.com");
        
        
        TextView view3 = (TextView) view.findViewById(R.id.view3);
        view3.setText("Llamanos: +567335234");
        bindAction(view3, new MailAction(
        new ActivityIntentLauncher()
        , "Correo: "));
    }

    @Override
    protected void onShow(RegistroDSItem item) {
        // set the title for this fragment
        getActivity().setTitle("CONTACTANOS");
    }

}

