
package com.ibm.mobileappbuilder.hackathon70020161014152544.ds;

import ibmmobileappbuilder.ds.Count;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.ds.Distinct;
import ibmmobileappbuilder.ds.Pagination;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import ibmmobileappbuilder.util.FilterUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * "DataSource0DS" static data source (22cd9b64-a179-4399-98ea-d13671b62ede)
 */
public class DataSource0DS implements Datasource<DataSource0DSSchemaItem>, Count,
            Pagination<DataSource0DSSchemaItem>, Distinct {

    private static final int PAGE_SIZE = 20;

    private SearchOptions searchOptions;

    public static DataSource0DS getInstance(SearchOptions searchOptions){
        return new DataSource0DS(searchOptions);
    }

    private DataSource0DS(SearchOptions searchOptions){
        this.searchOptions = searchOptions;
    }

    @Override
    public void getItems(Listener<List<DataSource0DSSchemaItem>> listener) {
        listener.onSuccess(DataSource0DSItems.ITEMS);
    }

    @Override
    public int getPageSize(){
        return PAGE_SIZE;
    }

    @Override
    public void getItem(String id, Listener<DataSource0DSSchemaItem> listener) {
        final int pos = Integer.parseInt(id);
        if(DataSource0DSItems.ITEMS.size() <= pos){
        	listener.onSuccess(new DataSource0DSSchemaItem());
        }
        else {
	        DataSource0DSSchemaItem dc = DataSource0DSItems.ITEMS.get(pos);
	        if( dc != null)
	            listener.onSuccess(dc);
	        else
	            listener.onFailure(new IllegalArgumentException("DataSource0DSSchemaItem not found: " + pos));
	    }
    }

    @Override public int getCount(){
        return DataSource0DSItems.ITEMS.size();
    }

    @Override
    public void getItems(int pagenum, Listener<List<DataSource0DSSchemaItem>> listener) {
        int first = pagenum * PAGE_SIZE;
        int last = first + PAGE_SIZE;
        ArrayList<DataSource0DSSchemaItem> result = new ArrayList<DataSource0DSSchemaItem>();
        List<DataSource0DSSchemaItem> filteredList = applySearchOptions(DataSource0DSItems.ITEMS);
        if(first < filteredList.size())
            for (int i = first; (i < last) && (i < filteredList.size()); i++)
                result.add(filteredList.get(i));

        listener.onSuccess(result);
    }

    @Override
    public void onSearchTextChanged(String s){
        searchOptions.setSearchText(s);
    }

    @Override
    public void addFilter(Filter filter){
        searchOptions.addFilter(filter);
    }

    @Override
    public void clearFilters() {
        searchOptions.setFilters(null);
    }

    private List<DataSource0DSSchemaItem> applySearchOptions(List<DataSource0DSSchemaItem> result) {
        List<DataSource0DSSchemaItem> filteredList = result;

        //Searching options
        String searchText = searchOptions.getSearchText();

        if(searchOptions.getFixedFilters() != null)
            filteredList = applyFilters(filteredList, searchOptions.getFixedFilters());

        if(searchOptions.getFilters() != null)
            filteredList = applyFilters(filteredList, searchOptions.getFilters());

        if (searchText != null && !"".equals(searchText))
            filteredList = applySearch(filteredList, searchText);

        //Sorting options
        Comparator comparator = searchOptions.getSortComparator();
        if (comparator != null) {
            if (searchOptions.isSortAscending()) {
                Collections.sort(filteredList, comparator);
            } else {
                Collections.sort(filteredList, Collections.reverseOrder(comparator));
            }
        }

        return filteredList;
    }

    private List<DataSource0DSSchemaItem> applySearch(List<DataSource0DSSchemaItem> items, String searchText) {
        List<DataSource0DSSchemaItem> filteredList = new ArrayList<>();

        for (DataSource0DSSchemaItem item : items) {
                        
            if (FilterUtils.searchInString(item.id, searchText) ||
            FilterUtils.searchInString(item.text1, searchText) ||
            FilterUtils.searchInString(item.text2, searchText) ||
            FilterUtils.searchInString(item.text3, searchText))
            {
                filteredList.add(item);
            }
        }

        return filteredList;

    }

    private List<DataSource0DSSchemaItem> applyFilters(List<DataSource0DSSchemaItem> items, List<Filter> filters) {
        List<DataSource0DSSchemaItem> filteredList = new ArrayList<>();

        for (DataSource0DSSchemaItem item : items) {
            if (
                FilterUtils.applyFilters("id", item.id, filters) &&
                FilterUtils.applyFilters("text1", item.text1, filters) &&
                FilterUtils.applyFilters("text2", item.text2, filters) &&
                FilterUtils.applyFilters("text3", item.text3, filters) &&
                FilterUtils.applyFilters("image1", item.image1, filters) &&
                FilterUtils.applyFilters("image2", item.image2, filters)
                ){

                filteredList.add(item);
            }
        }

        return filteredList;
    }

    // Distinct interface

    @Override
    public void getUniqueValuesFor(String columnName, Listener<List<String>> listener) {
        List<DataSource0DSSchemaItem> filteredList = applySearchOptions(DataSource0DSItems.ITEMS);
        listener.onSuccess(mapItems(filteredList, columnName));
    }

    private List<String> mapItems(List<DataSource0DSSchemaItem> items, String columnName){
        // return only unique values
        ArrayList<String> res = new ArrayList();
        for (DataSource0DSSchemaItem item: items){
            String mapped = mapItem(item, columnName);
            if(mapped != null && !res.contains(mapped))
                res.add(mapped);
        }

        return res;
    }

    private String mapItem(DataSource0DSSchemaItem item, String columnName){
        // get fields
        switch (columnName){
                        
            case "id":
                return item.id;
            
            case "text1":
                return item.text1;
            
            case "text2":
                return item.text2;
            
            case "text3":
                return item.text3;
            default:
               return null;
        }
    }
}


