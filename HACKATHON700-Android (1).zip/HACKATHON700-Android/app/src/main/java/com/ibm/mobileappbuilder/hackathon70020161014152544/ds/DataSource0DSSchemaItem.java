
package com.ibm.mobileappbuilder.hackathon70020161014152544.ds;
import java.net.URL;
import ibmmobileappbuilder.util.StringUtils;
import java.net.URL;
import ibmmobileappbuilder.util.StringUtils;

import ibmmobileappbuilder.mvp.model.IdentifiableBean;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class DataSource0DSSchemaItem implements Parcelable, IdentifiableBean {

    @SerializedName("id") public String id;
    @SerializedName("text1") public String text1;
    @SerializedName("text2") public String text2;
    @SerializedName("text3") public String text3;
    @SerializedName("image1") public Integer image1;
    @SerializedName("image2") public Integer image2;

    @Override
    public String getIdentifiableId() {
      return id;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(text1);
        dest.writeString(text2);
        dest.writeString(text3);
        dest.writeValue(image1);
        dest.writeValue(image2);
    }

    public static final Creator<DataSource0DSSchemaItem> CREATOR = new Creator<DataSource0DSSchemaItem>() {
        @Override
        public DataSource0DSSchemaItem createFromParcel(Parcel in) {
            DataSource0DSSchemaItem item = new DataSource0DSSchemaItem();

            item.id = in.readString();
            item.text1 = in.readString();
            item.text2 = in.readString();
            item.text3 = in.readString();
            item.image1 = (Integer) in.readValue(null);
            item.image2 = (Integer) in.readValue(null);
            return item;
        }

        @Override
        public DataSource0DSSchemaItem[] newArray(int size) {
            return new DataSource0DSSchemaItem[size];
        }
    };

}


