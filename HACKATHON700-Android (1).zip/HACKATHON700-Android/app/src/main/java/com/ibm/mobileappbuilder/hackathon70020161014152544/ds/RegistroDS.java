

package com.ibm.mobileappbuilder.hackathon70020161014152544.ds;

import android.content.Context;

import java.net.URL;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.restds.AppNowDatasource;
import ibmmobileappbuilder.util.StringUtils;
import ibmmobileappbuilder.ds.restds.TypedByteArrayUtils;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

/**
 * "RegistroDS" data source. (e37eb8dc-6eb2-4635-8592-5eb9696050e3)
 */
public class RegistroDS extends AppNowDatasource<RegistroDSItem>{

    // default page size
    private static final int PAGE_SIZE = 20;

    private RegistroDSService service;

    public static RegistroDS getInstance(SearchOptions searchOptions){
        return new RegistroDS(searchOptions);
    }

    private RegistroDS(SearchOptions searchOptions) {
        super(searchOptions);
        this.service = RegistroDSService.getInstance();
    }

    @Override
    public void getItem(String id, final Listener<RegistroDSItem> listener) {
        if ("0".equals(id)) {
                        getItems(new Listener<List<RegistroDSItem>>() {
                @Override
                public void onSuccess(List<RegistroDSItem> items) {
                    if(items != null && items.size() > 0) {
                        listener.onSuccess(items.get(0));
                    } else {
                        listener.onSuccess(new RegistroDSItem());
                    }
                }

                @Override
                public void onFailure(Exception e) {
                    listener.onFailure(e);
                }
            });
        } else {
                      service.getServiceProxy().getRegistroDSItemById(id, new Callback<RegistroDSItem>() {
                @Override
                public void success(RegistroDSItem result, Response response) {
                                        listener.onSuccess(result);
                }

                @Override
                public void failure(RetrofitError error) {
                                        listener.onFailure(error);
                }
            });
        }
    }

    @Override
    public void getItems(final Listener<List<RegistroDSItem>> listener) {
        getItems(0, listener);
    }

    @Override
    public void getItems(int pagenum, final Listener<List<RegistroDSItem>> listener) {
        String conditions = getConditions(searchOptions, getSearchableFields());
        int skipNum = pagenum * PAGE_SIZE;
        String skip = skipNum == 0 ? null : String.valueOf(skipNum);
        String limit = PAGE_SIZE == 0 ? null: String.valueOf(PAGE_SIZE);
        String sort = getSort(searchOptions);
                service.getServiceProxy().queryRegistroDSItem(
                skip,
                limit,
                conditions,
                sort,
                null,
                null,
                new Callback<List<RegistroDSItem>>() {
            @Override
            public void success(List<RegistroDSItem> result, Response response) {
                                listener.onSuccess(result);
            }

            @Override
            public void failure(RetrofitError error) {
                                listener.onFailure(error);
            }
        });
    }

    private String[] getSearchableFields() {
        return new String[]{"contactar", "usuario", "nombre", "empresa"};
    }

    // Pagination

    @Override
    public int getPageSize(){
        return PAGE_SIZE;
    }

    @Override
    public void getUniqueValuesFor(String searchStr, final Listener<List<String>> listener) {
        String conditions = getConditions(searchOptions, getSearchableFields());
                service.getServiceProxy().distinct(searchStr, conditions, new Callback<List<String>>() {
             @Override
             public void success(List<String> result, Response response) {
                                  result.removeAll(Collections.<String>singleton(null));
                 listener.onSuccess(result);
             }

             @Override
             public void failure(RetrofitError error) {
                                  listener.onFailure(error);
             }
        });
    }

    @Override
    public URL getImageUrl(String path) {
        return service.getImageUrl(path);
    }

    @Override
    public void create(RegistroDSItem item, Listener<RegistroDSItem> listener) {
                    
        if(item.logoUri != null){
            service.getServiceProxy().createRegistroDSItem(item,
                TypedByteArrayUtils.fromUri(item.logoUri),
                callbackFor(listener));
        }
        else
            service.getServiceProxy().createRegistroDSItem(item, callbackFor(listener));
        
    }

    private Callback<RegistroDSItem> callbackFor(final Listener<RegistroDSItem> listener) {
      return new Callback<RegistroDSItem>() {
          @Override
          public void success(RegistroDSItem item, Response response) {
                            listener.onSuccess(item);
          }

          @Override
          public void failure(RetrofitError error) {
                            listener.onFailure(error);
          }
      };
    }

    @Override
    public void updateItem(RegistroDSItem item, Listener<RegistroDSItem> listener) {
                    
        if(item.logoUri != null){
            service.getServiceProxy().updateRegistroDSItem(item.getIdentifiableId(),
                item,
                TypedByteArrayUtils.fromUri(item.logoUri),
                callbackFor(listener));
        }
        else
            service.getServiceProxy().updateRegistroDSItem(item.getIdentifiableId(), item, callbackFor(listener));
        
    }

    @Override
    public void deleteItem(RegistroDSItem item, final Listener<RegistroDSItem> listener) {
                service.getServiceProxy().deleteRegistroDSItemById(item.getIdentifiableId(), new Callback<RegistroDSItem>() {
            @Override
            public void success(RegistroDSItem result, Response response) {
                                listener.onSuccess(result);
            }

            @Override
            public void failure(RetrofitError error) {
                                listener.onFailure(error);
            }
        });
    }

    @Override
    public void deleteItems(List<RegistroDSItem> items, final Listener<RegistroDSItem> listener) {
                service.getServiceProxy().deleteByIds(collectIds(items), new Callback<List<RegistroDSItem>>() {
            @Override
            public void success(List<RegistroDSItem> item, Response response) {
                                listener.onSuccess(null);
            }

            @Override
            public void failure(RetrofitError error) {
                                listener.onFailure(error);
            }
        });
    }

    protected List<String> collectIds(List<RegistroDSItem> items){
        List<String> ids = new ArrayList<>();
        for(RegistroDSItem item: items){
            ids.add(item.getIdentifiableId());
        }
        return ids;
    }

}

